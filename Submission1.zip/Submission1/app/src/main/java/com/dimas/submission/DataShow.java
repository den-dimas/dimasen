package com.dimas.submission;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class DataShow extends AppCompatActivity {

    private ArrayList<Andro> list = new ArrayList<>();
    private int position;
    private TextView name, detail;
    private ImageView photo;

    public ArrayList<Andro> getListCreator() {
        return list;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_show);

        name = (TextView)findViewById(R.id.tv_item_name);
        detail = (TextView)findViewById(R.id.tv_item_detail);
        photo = (ImageView)findViewById(R.id.img_item_photo);

        Bundle extras = getIntent().getExtras();
        position = extras.getInt("position");
        Log.e("hasil intent", String.valueOf(position));

        list.addAll(DataAndro.getListData());

        name.setText(list.get(position).getName());
        detail.setText(list.get(position).getDetail());
        Andro c = getListCreator().get(position);
        Glide.with(getApplicationContext())
                .load(c.getPhoto())
                .apply(new RequestOptions().override(210,210))
                .into(photo);

    }

}
