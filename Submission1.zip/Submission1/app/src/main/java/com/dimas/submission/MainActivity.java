package com.dimas.submission;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvAndroid;
    private ArrayList<Andro> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvAndroid = findViewById(R.id.rv_android);
        rvAndroid.setHasFixedSize(true);

        list.addAll(DataAndro.getListData());
        showRecyclerList();

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("List Android");
        }

    }

    private void showRecyclerList() {
        rvAndroid.setLayoutManager(new LinearLayoutManager(this));
        ListAndroAdapter listAndroAdapter = new ListAndroAdapter(list,getApplicationContext());
        rvAndroid.setAdapter(listAndroAdapter);

        listAndroAdapter.setOnItemClickCallback(new ListAndroAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Andro data) {
                showSelectedAndro(data);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_profile:
                startActivity(new Intent(this,TentangActivity.class));
                Toast.makeText(getApplicationContext(),"Profile",Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void showSelectedAndro(Andro data) {
        Toast.makeText(this, "Membuka " + data.getName(), Toast.LENGTH_SHORT).show();
    }

}
