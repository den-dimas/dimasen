package com.dimas.submission;

import java.util.ArrayList;

public class DataAndro<list> {
    public static String[] androidNames = {
            "Android 1.0 & 1.1: Alpha & Beta",
            "Android 1.5: Cupcake",
            "Android 1.6: Donut",
            "Android 2.0 & 2.1: Eclair",
            "Android 2.2: Froyo (Frozen Yoghurt)",
            "Android 2.3: Gingerbread",
            "Android 3.0 & 3.2: Honeycomb",
            "Android 4.0: Ice Cream Sandwich",
            "Android 4.1 & 4.3: Jelly Bean",
            "Android 4.4: KitKat",
            "Android 5.0 & 5.1: Lollipop",
            "Android 6.0: Marshmallow",
            "Android 7.0 & 7.1: Nougat",
            "Android 8.0 & 8.1: Oreo",
            "Android 9.0: Pie",
            "Android Q Beta"
    };

    public  static String[] androidDetails = {
            "Kedua versi awal Android ini mungkin agak asing kamu dengarkan. Pasalnya versi Android 1.0 Astro (Alpha) dan Android 1.1 Bender (Beta) ini belum diluncurkan secara publik untuk kebutuhan komersil.\n" +
                    "\n" +
                    "Pada versi pertama inilah Konsep OS Android di kembangkan dengan menggunakan API Level Versi 1, hingga menjadi sekarang ini dengan ciri khas tersendiri, semua itu di mulai Versi 1.0 yang hadir dengan beberapa fitur Core OS Android yang bisa kalian nikmati sekarang ini, seperti :\n" +
                    "\n" +
                    "  - Android Market (sekarang di kenal dengan Google Play Store)\n" +
                    "  - Integrasi Google Apps (Gmail, Maps, Calender, etc)\n" +
                    "  - Availability Bluetooth dan Wi-Fi Support\n" +
                    "  - Notfication / Statusbar (Ciri khas OS Android)\n" +
                    "\n" +
                    "Selain itu, masih ada banyak fitur kunci utama yang ada pada Versi Pertama OS Android tersebut, tetapi hanya 4 hal diatas saja yang harus kalian ketahui, karena ke-4 Fitur diatas memang sudah sangat bervolusi sekarang ini.\n" +
                    "\n" +
                    "Fakta menarik dari OS Android 1.0 adalah karena pada versi ini OS Android belum memiliki sebuah Codename, sehingga tidak ada nama resmi dari OS Android Pertama ini, banyak yang menyebutkan bahwa Versi Pertama OS Android ini memiliki Codename Alpha, tetapi sampai saat ini masih belum bisa di Konfirmasi kebenarannya.\n" +
                    "\n" +
                    "\n" +
                    "Pada tahun berikutnya yaitu tahun 2009, OS Android mendapat pembaharuan Versi ke 1.1 yang di kenali dengan Codename Beta.\n" +
                    "Versi OS Android 1.1 ini memiliki API Level 2 dengan beberapa peningkatan sebagai berikut :\n" +
                    "\n" +
                    "  - Peningkatan fitur Maps\n"+
                    "  - Peningkatan Minor dan perbaikian beberapa Bugs pada versi Android sebelumnya\n"+
                    "\n" +
                    "Update Versi OS Android 1.1 ini di ketahui hanya di distribusikan secara resmi untuk Smartphone HTC Dream atau T-Mobile G1 saja, yang memang seperti yang sudah kami jelaskan bahwa Smartphone Komersial itulah yang Pertama kali menggunakan OS Android secara resmi.",




            "Di tahun yang sama yaitu pada tahun 2009, kini OS Android sudah mulai menggunakan Codename secara Resmi untuk nama dari Versi OS Android tersebut agar mudah di kenali oleh penggunannya, untuk Codename dari Android 1.5 adalah Cupcake dengan menggunakan API Level 3.\n" +
                    "\n" +
                    "Ada banyak pembaharuan pada versi OS Android ini dan selanjutnya pada OS Android ini juga persebaran penggunaan OS Android sudah kian membanyak, karena sudah di Implementasikan oleh beberapa Produsen Smartphone kala itu, seperti Samsung dan Sony Ericsson." +
                    "\n" +
                    "Beberapa Update Besar (Major) pada versi Android 1.5 ini adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Kemampuan menggunakan Virtual Keyboard\n" +
                    "  - Kemampuan menggunakan Widget\n" +
                    "  - Penambahan Efek Transisi System\n" +
                    "  - Fitur Rotasi terintegrasi dengan Sensor terkait\n" +
                    "  - Support Video dengan Formal MP4 dan 3GP\n" +
                    "\n" +
                    "Jika, dilihat maka dari Versi Android 1.5 inilah semua hal hebat mulai ada di OS Android, karena selain sebagai OS Android pertama yang menggunakan Codename, versi OS Android 1.5 ini juga mengalami peningkatan besar dari segi User Experience.",



            "Lagi-lagi pada tahun 2009 pihak Google kembali merilis versi OS Android baru yaitu versi Android 1.6 dengan Codename Donut (API Level 4).\n" +
                    "\n" +
                    "Teradapat beragam pembaharuan fitur dan juga perbaikan besar dari versi sebelumnya yang ada pada Versi Android 1.6 tersebut, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Peningkatan fitur Intenal Search\n" +
                    "  - Integrasi Fitur Multimedia agar lebih cepat di gunakan (Gallery, Camera, Camcoder, dll)\n" +
                    "  - Penambahan fitur VPN\n" +
                    "  - Penambahan Teknologi SIM dengan Implementasi jaringan CMDA / EVDO yang awalnya cuma GSM saja.\n" +
                    "  - Mendukung hingga Resolusi layar WVGA (768x470)\n" +
                    "\n" +
                    "Pada versi OS Android 1.6 ini OS Android sudah mulai di kenali oleh masyrakat luas, meski demikian masih ada sedikit saja OEM yang berani mendistribusikan Smartphone dengan OS Android.\n" +
                    "\n" +
                    "Karena pengaruh Featured Phones dengan OS Java yang masih begitu kuat pada zaman itu, tetapi disinilah mulanya OS Android mulai menggeliat dan naik ke permukaan.",


            "Pada versi ini di mulailah eranya OS Android, karena pada masa inilah OS Android sudah bisa di terima oleh masyarakat luas, karena beberapa OEM Smartphone sudah mulai banyak membuat Smartphone dengan OS Android untuk di jual kepasaran.\n" +
                    "\n" +
                    "OS Android versi 2.0 ini di kenali dengan Codename Eclair (API Level 5) yang waktu perilisannya adalah pada tahun 2009 juga, yaitu di tahun dimana OS Android 1.1 hingga 1.6 Exist.\n" +
                    "\n" +
                    "OS Android 2.0 ini juga membawa perubahan yang cukup besar yaitu adalah sebagai berikut :\n"+
                    "\n" +
                    "  - Dukungan HTLM5\n" +
                    "  - Multiple Integrated Mail Account\n" +
                    "  - Support Bluetooh 2.1\n" +
                    "  - Peningkatan Performa dan peningkatan UX & UI\n" +
                    "  - Peningkatan fitur Google Maps Mobile\n" +
                    "  - Lahirnya Fitur Live Wallpaper yang melegenda\n" +
                    "\n" +
                    "Selanjutnya, pada versi Android 2.0 ini, terdapat lagi 2 buah versi Update OS, sehingga muncul Sub-Version dengan Codename sama, tetapi berbeda versi dan API Level, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Android 2.0.1 (API Level 6)\n" +
                    "  - Android 2.1 (API Level 7)\n" +
                    "\n" +
                    "Tetapi, pada Update tersebut hanya di berikan Update Minor untuk memperbaiki beberapa Bugs yang ada dari versi sebelumnya, untuk Codenamenya masih sama-sama menggunakan nama Eclair sebagai alat Brandingnya.",



            "Tahun 2010, pihak Google kembali merilis OS Android terbaru dengan peningkatan besar-besaran dari segi Fitur dan Fungsionalitas, OS Android 2.2 di kenali dengan Codename Froyo yang merupakan hasil singkatan dari Frozen Yogurt (API Level 8).\n" +
                    "\n" +
                    "Ada beberapa Update besar bersifat Major yang telah di rekam dari jejak sejarah versi OS Android ini, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Peningkatan Performa yang signifitan dengan Impelentasi JIT (Just in Time) Module\n" +
                    "  - Support Chrome\n" +
                    "  - Penambahan fitur Push Notifications\n" +
                    "  - Pembaharuan Launcher dan pembaharuan beberapa Aplikasi Core OS Android\n" +
                    "  - Penambahan Wi-Fi Tethering dan USB Tethering (Sejarah penting untuk Fakir Kouta)\n" +
                    "  - Support fitur gambar formal GIF\n" +
                    "  - Dukungan dari Adobe Flash\n" +
                    "  - Dukungan hingga Resolusi layar HD (1280 x 720)\n" +
                    "  - Support keamanan dengan metode angka atau numeric\n" +
                    "\n" +
                    "Selanjutnya, sama seperti OS Android 2.0, pada versi Android Froyo ini, pihak Google juga diketahui mengupdate versi Android 2.2 ini ke beberapa Sub Versi, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Android 2.2.1\n" +
                    "  - Android 2.2.2\n" +
                    "  - Android 2.2.3\n" +
                    "\n" +
                    "Hanya, saja pada pembaharuan Sub Versi ini, tetap menggunakan API level 8 dan tidak ada perubahan pada Codename, karena sifat dari Pembaharuan tersebut hanya Minor saja.",



            "Pada versi ini OS Android sudah mendunia, karena pada saat OS Android berada pada versi 2.3 inilah banyak sekali Produsen Smartphone yang sudah menggunakan OS Android untuk menjadi sebuah OS Primer pada Smartphone yang mereka jual, jejak rekamnya terlacak mulai dari tahun 2010.\n" +
                    "\n" +
                    "Karena pada masa-masa ini bukan hanya Brand Smartphone International saja yang telah mengimplementasikan OS Android pada Smartphone yang mereka buat, karena saat ini Brand Lokal pun juga sudah mulai menggunakan OS Android untuk mencoba peruntungan baru." +
                    "\n" +
                    "OS Android 2.3 ini memang menjadi salah satu pilar sejarah penting dalam historisnya, OS Android 2.3 ini di kenali dengan Codename Gingerbread (API Level 9), pada versi OS Android 2.3 ini juga pihak Google memberikan Update besar-besaran terhadap beragam Support fitur dan Integrasi Hardware yang antara lain adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Pembaharuan tampilan (UI)\n" +
                    "  - Support hingga ukuran layar WXGA (1366 x 768)\n" +
                    "  - Dukungan fitur NFC\n" +
                    "  - Dukungan Integrasi Equalizer\n" +
                    "  - Peningkatan pada konsumsi daya baterai yang kini sudah lebih efisien\n" +
                    "  - OS Android Pertama yang menggunakan Easter Egg!\n" +
                    "\n" +
                    "Selain itu pada versi Android 2.3 ini, pihak Google juga beberapa kali memberikan Update dengan bertambahnya Sub Versi OS Android 2.3 tersebut, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Android 2.3.1 (API Level 9)\n" +
                    "  - Android 2.3.2 (API Level 9)\n" +
                    "  - Android 2.3.3 (API Level 10)\n" +
                    "  - Android 2.3.4 (API Level 10)\n" +
                    "  - Android 2.3.5 (API Level 10)\n" +
                    "  - Android 2.3.6 (API Level 10)\n" +
                    "  - Android 2.3.7 (API Level 10)\n" +
                    "\n" +
                    "Era Android 2.3 atau Gingerbread ini memang tidak bisa terlupakan, karena seperti yang telah kami singgung sebelumnya, pada era inilah OS Android sudah mendunia, diakui sebagai sebuah OS yang menjanjikan dan sudah mendapat Popularitas tersendiri.\n",



            "OS Versi ini menjadi OS Android yang paling unik, kenapa? karena tidak tersedia untuk Smartphone dan memiliki Sub Versi yang paling banyak, diantara Sub Versi pada versi OS Android lain, selanjutnya OS Android 3.0 ini juga di mulainya sebuah sejarah baru, yaitu sejarah penggunaan Android Tablet!\n" +
                    "\n" +
                    "OS Android 3.0 ini bukan di buat untuk Smartphone, melainkan untuk Tablet, sehingga OS Android ini tidak pernah di distribusikan ke Smartphone secara resmi, Android 3.0 ini memiliki Codename Honeycomb yang di rilis pada tahun 2011 dengan API Level 11\n" +
                    "\n" +
                    "Selanjutnya, ada beberapa List Update yang berpengaruh untuk kita sekarang yang datang dari OS Android satu ini, yaitu adalah :\n" +
                    "\n" +
                    "  - OS Android yang bisa di gunakan di Tablet\n" +
                    "  - Fitur USB On The Go\n" +
                    "  - Peningkatan akselerasi Hardware\n" +
                    "\n" +
                    "Untuk Tablet pertama yang menggunakan OS Android dengan versi 2.3 Honeycomb ini adalah Tablet Motorola Xoom, tetapi pada saat itu, nampaknya penggunan Tablet memang masih menjadi hal yang tidak umum.\n" +
                    "\n" +
                    "Selanjutnya, pada versi Android Honeycomb ini, Google juga paling banyak memberikan Update pada Sub Versinya, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Android 3.1 (API Level 12)\n" +
                    "  - Android 3.2 (API Level 13)\n" +
                    "  - Android 3.2.1\n" +
                    "  - Android 3.2.2\n" +
                    "  - Android 3.2.3\n" +
                    "  - Android 3.2.4\n" +
                    "  - Android 3.2.5\n" +
                    "\n" +
                    "Sehingga, jika kalian adalah pengguna Tablet Android, maka disinilah eranya Tablet Android di mulai, karena jika tidak ada OS Android 3.0 ini, maka mungkin tidak ada yang namanya Tablet Android sekarang ini.",



            "Pada tahun 2011 pihak Google kembali merilis OS Android baru dengan membawa peningkatan besar pada sisi User Interface (Tampilan) dengan menggunakan Branding nama 'Holo', Android 4.0 ini di kenali sebagai Ice Cream Sandwich dengan API Level 14.\n" +
            "\n" +
            "Design Holo pada Android 4.0 Ice Cream Sandwich ini memang sangat berbeda dari versi OS Android sebelumnya, karena perubahan yang terjadi, terlihat menyeluruh, dengan Background Default berupa Gradient.\n" +
            "\n" +
            "Beberapa, fitur penting pada Update Android 4.0 tersebut adalah antara lain :\n" +
            "\n" +
            "  - OS Android Pertama yang menggunakan Font Roboto yang legendaris\n" +
            "  - Dukungan Pertama terhadap fungsi Virtual Navigation Button\n" +
            "  - Peningkatan fungsi Lock Screen\n" +
            "  - OS Android Pertama yang mendukung fungsi Face Unlock\n" +
            "  - Pengenalan Android Beam yang sangat terasa sekarang manfaatnya dari fitur NFC\n" +
            "  - Dukungan perekaman default dari aplikasi Camcoder asli OS Android hingga resolusi 1080p (FullHD)\n" +
            "\n" +
            "Sejarah, juga mencatat OS Android Ice Cream Sandwich ini juga mendapatkan beberapa kali Update Sub Versi, yaitu adalah sebagai berikut :\n" +
            "\n" +
            "  - Android 4.0.1\n" +
            "  - Android 4.0.2\n" +
            "  - Android 4.0.3 (API Level 15)\n" +
            "  - Android 4.0.4\n" +
            "\n" +
            "Design Holo pada OS Android Ice Cream Sandwich ini sangat di sukai oleh pengguna Smartphone Android pada masa itu, karena tampilan antar mukanya memang benar-benar keren pada saat itu dan menjadi seakan sangat modern, Design Holo tersebut juga bertahan hingga tahun-tahun selanjutnya.",



            "Dirilis pada tahun 2012, OS Android 4.1 yang di kenali dengan Codename Jellybean ini menggunakan API Level 16 yang pada Updatenya memberikan peningkatan performa yang sangat baik dengan adanya Fitur Project Butter yang membuat kinerja OS Android 4.1 menjadi sangat cepat dan responsif di bandingkan dari seri versi sebelumnya.\n" +
                    "\n" +
                    "Pada versi ini Google juga memberikan beberapa Update penting, yaitu adalah sebagai berikut :" +
                    "\n" +
                    "  - Peningkatan performa navigasi meliputi transisi dan pengolahan grafis secara signifikan\n" +
                    "  - Dukungan fitur USB Audio\n" +
                    "  - Dukungan fitur Screensaver\n" +
                    "  - Peningkatan konsumsi Bluetooth yang ramah energi\n" +
                    "  - Peningkatan signifikan untuk Games berbasis OS Android, karena telah menggunakan OpenGL ES 3.0\n" +
                    "  - OS Android Pertama untuk fitur Emoji\n" +
                    "  - Mendukung hingga Resolusi layar 4K (2160 x 3840)\n" +
                    "\n" +
                    "Selanjutnya, OS Android Jelly Bean ini juga beberapa kali mendapat pembaharuan pada Sub Versinya, yaitu sebagai berikut :\n" +
                    "\n" +
                    "  - Android 4.1.1\n" +
                    "  - Android 4.1.2\n" +
                    "  - Android 4.2 (API Level 17)\n" +
                    "  - Android 4.2.1\n" +
                    "  - Android 4.2.2\n" +
                    "  - Android 4.3 (API Level 18)\n" +
                    "  - Android 4.3.1\n" +
                    "\n" +
                    "OS Android JellyBean ini memang tidak begitu memberikan kesan yang banyak, untuk para penggunannya, karena dari segi tampilan, memang hampir sama persis dengan Android 4.0 Ice Cream Sandwich, sehingga banyak pengguna di masa itu yang memilih lebih bertahan menggunakan Androd 4.0 saja, ketimbang melakukan Update, itulah fakta yang terjadi pada saat itu.",



            "Jika, pada versi OS Android sebelumnya tidak memberikan kesan yang menakjubkan, maka pada OS Android 4.4 atau yang biasa di kenal dengan Codename KitKat ini, memberikan hal yang bertolak belakang dari OS Android Jellybean." +
                    "\n" +
                    "Karena perlu kalian ketahui OS Android 4.4 KitKat ini di katakan menjadi salah satu OS Android terbaik yang pernah di buat oleh Google, karena Performa dan Stabilitas yang ada pada OS Android 4.4 KitKat ini memang sangat baik dan bahkan terlampau sangat baik.\n" +
                    "\n" +
                    "Hal tersebut, terjadi karena Google telah memberikan Standard baru bagi penggunaan OS Android di masa itu, yaitu RAM minimal harus menggunakan kapasitas 512MB, sehingga disinilah titik balik terjadinya penggunaan RAM di OS Android yang kian membesar tiap tahunnya.\n" +
                    "\n" +
                    "Asumsinya adalah semakin besar RAM, maka kinerja OS Android akan semakin baik, lalu di mulailah era Smartphone Android dengan RAM besar bermunculan setelahnya.\n" +
                    "\n" +
                    "OS Android 4.4 ini menggunakan API Level 19 dengan peningkatan fungsi sebagai berikut :\n" +
                    "  - Dukungan teknologi Caching terbaru yang di beri nama ART (Android Runtime)\n" +
                    "  - Efisiensi resource OS untuk Smartphone berspesifikasi rendah (Inilah kenapa Android KitKat menjadi yang terbaik, karena mampun berjalan sempurna meski dengan Spesifkasi Smartphone Android yang rendah)\n" +
                    "  - Penambahan variant transisi pada Framework\n" +
                    "\n" +
                    "Selanjutnya, di era Android 4.4 KitKat inilah, OS Android kian melebarkan sayapnya untuk menyasar Gadget Non-Smartphone, karena pada masa ini Google telah merilis OS Android berbasis KitKat untuk penggunaan Wearable seperti Smartwatch.\n" +
                    "\n" +
                    "Untuk jejak rekam update Sub Versi dan variant Android 4.4 KitKat, bisa kalian lihat di bawah ini :\n" +
                    "\n" +
                    "  - Android 4.4.1\n" +
                    "  - Android 4.4.2\n" +
                    "  - Android 4.4.3\n" +
                    "  - Android 4.4.4\n" +
                    "  - Android 4.4W (Wearable, API Level 20)\n" +
                    "  - Android 4.4W.1\n" +
                    "  - Android 4.4W.2\n" +
                    "\n" +
                    "Fakta menarik dari OS Android KitKat ini adalah menurut sumber bahwa OS Android ini mencetak penggunaan OS Android pada Smartphone Android terbanyak sepanjang masa, karena pada masa Android KitKat inilah, ada banyak sekali jenis Smartphone yang di jual secara Massive masuk ke dalam Pasar Global ataupun Domestik.",



            "Era baru tampilan OS Android yang Modern di mulai pada OS Android 5.0 atau yang lebih kenal dengan Codename Lollipop tersebut, karena di OS inilah nama Branding 'Material Design' pertama kali di gunakan." +
            "\n" +
            "Karena mengusung konsep Material Design, maka ada perubahan besar-besaran yang terjadi pada tampilan OS Android satu ini, jika sebelumnya menggunakan tampilan Holo dengan gaya Bold dan Gradient.\n" +
            "\n" +
            "OS Android Lollipop ini menggunakan API Level 21 dengan beberapa fitur penting di dalamnya, Google sendiri baru merilis OS Android Lollipop ini pada tahun 2014 dengan inti pembaharuan sebagai berikut :\n" +
            "\n" +
            "  - Peningkatan performa yang lebih efektif\n" +
            "  - Dukungan pertama untuk jenis CPU 64-bit\n" +
            "  - Menggunakan OpenGL ES 3.1 yang memberikan dampak besar terhadap fungsi GPU (Penting untuk para Gamers)\n" +
            "  - Performa konsumsi baterai yang lebih efisien\n" +
            "  - Dukungan Smart Lock dengan beragam opsi\n" +
            "  - OS Android Pertama untuk teknologi Dual SIM\n" +
            "  - Dukungan pertama untuk sistem Upgrade OS via Internet (OTA) langsung dari System\n" +
            "\n" +
            "Selanjutnya, OS Androd 5.0 ini juga beberapa kali mendapat pembaharuan Sub Versi dengan jejak rekam sebagai berikut :\n" +
            "\n" +
            "  - Android 5.0.1\n" +
            "  - Android 5.0.2\n" +
            "  - Android 5.1 (API Level 22)\n" +
            "  - Android 5.1.1\n" +
            "\n" +
            "Sehingga, hingga sekarang peninggalan OS Android 5.0 Lollipop ini tetap bisa kita rasakan dampak besarnya, yaitu adalah tampilan antar muka dari OS Android tersebutlah yang menjadi peninggalan terbesar Android Lollipop yang masih bisa kita rasakan hingga sekarang.",



            "Pada tahun 2015 Google kembali merilis versi terbaru dari OS Android dengan nama yang cukup susah untuk di ketik, yaitu dengan Codename Marshmallow (API Level 23), membawa peningkatan yang lumayan banyak.\n" +
                    "\n" +
                    "Menjadikan OS Android 6.0 Marshmallow ini menjadi OS Android Modern Look yang paling banyak di gunakan dan paling lama di gunakan." +
                    "\n" +
                    "Karena jika kita melihat dari data yang tersaji, maka banyak sekali pengguna aktif dari OS Android Marshmallow tersebut, meski versi OS Android terbaru sudah di rilis oleh Google, hal tersebut terjadi karena OS Android 6.0 memang membawa sejumlah update yang sangat penting, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Dukungan Doze Mode, dimana konsumsi daya baterai akan hampir tidak di gunakan, ketika Smartphone tengan Standby atau Sleep\n" +
                    "  - OS Android Pertama untuk Teknologi Fingerprint\n" +
                    "  - OS Android Pertama untuk Teknologi USB Type-C\n" +
                    "  - Fitur baru yang bisa di gunakan untuk menambah kapasitas Memory Internal dengan bantuan dari kapasitas Memory External\n" +
                    "  - Support MIDI\n" +
                    "  - Update koleksi Emoji yang lebih banyak dan variatif\n" +
                    "\n" +
                    "Selanjutnya, OS Android 6.0 Marshmallow hanya 2 kali mendapatkan peningkatan Sub Versi, yaitu sebagai berikut :\n" +
                    "\n" +
                    "  - Android 6.0.1\n" +
                    "\n" +
                    "OS Android Marshmallow di katakan menjadi OS Android Revolusioner, karena dari era OS Android 6.0 inilah, beragam Inovasi di bidang teknologi dalam penggunaan OS Android, berkembang dengan sangat pesat.",



            "Pada era ini, OS Android kian makin maju dan makin Modern dari segi Teknologi, di mulai pada tahun 2016 sejak Google pertama kali merilis OS Android 7.0 ke publik yang di kenali dengan Codename Nougat (API Level 24).\n" +
                    "\n" +
                    "Versi Android ini langsung disambut baik oleh para pengguna Smartphone Android, karena dari sinilah Performa 3D rendering di OS Android semakin signifikan menunjukan perubahan yang sangat drastis.\n" +
                    "\n" +
                    "Sehingga para era inilah bermunculan banyak sekali Games Android dengan grafis fantastis yang bisa di nikmati oleh pengguna Smartphone Android, karena OS Android 7.0 Nougat ini secara resmi sudah mendukung Teknologi Vulkan, yang membuat Animasi 3D tampak lebih nyata.\n" +
                    "\n" +
                    "Selain itu, ada beberapa update besar yang hadir pada versi OS Android 7.0 ini, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Perkenalan fitur Daydream (Virtual Reality)\n" +
                    "  - Dukungan fitur Multi Windows terhadap aplikasi yang berjalan\n" +
                    "  - Dukungan pertama Vulkan 3D API Rendering (Gamers harus berterima kasih dengan ini!)\n" +
                    "  - Peningkatan pada sektor User Interface (UI) dan User Experience (UX)\n" +
                    "  - Update Emoji dengan koleksi lebih banyak\n" +
                    "  - Peningkatan Gesture Navigasi yang kini lebih responsif\n" +
                    "  - Pengayaan fitur Fingerprint\n" +
                    "\n" +
                    "Lalu, OS Android 7.0 ini juga beberapa kali di update oleh Google melalui Sub Versinya, yang bisa kalian lihat di bawah ini :\n" +
                    "\n" +
                    "  - Android 7.1 (API Level 25)\n" +
                    "  - Android 7.1.1\n" +
                    "  - Android 7.1.2\n" +
                    "\n" +
                    "Pada masa Android 7.0 atau Nougat inilah banyak sekali Games yang bersifat Online maupun Offline dengan grafis yang tinggi mulai banyak bermunculan, maka sekali lagi, jika kalian adalah Gamers dan kalian merasa ada perbedaan besar pada Games di OS Android lawas dan baru, maka salah satu alasan kenapa hal tersebut bisa terjadi, adalah karena adanya update dari Android 7.0 tersebut.",




            "Ini adalah OS Android yang paling manis, kalau menurut kami, karena selain menggunakan Codename yang familiar, yaitu adalah Oreo, faktanya OS Android 8.0 (API Level 26) ini juga hadir dengan beragam fungsi baru yang tentu saja manfaatnya bisa kita rasakan hingga sekarang ini." +
                    "\n" +
                    "Selanjutnya, pada era Android 8.0 dimulai sejak tahun 2017 inilah pihak Google membuat sebuah OS Android yang ramah dan bisa di jalankan dengan lancar pada Smartphone Android berspesifikasi rendah, Project tersebut di kenali dengan Project Android Go yang berbasis pada Android 8.0 versi Go (Lite).\n" +
                    "\n" +
                    "Selain itu, ada beberapa Update Major yang harus kalian ketahui pada versi Android 8.0 Oreo tersebut, yaitu adalah :\n" +
                    "\n" +
                    "  - Dukungan pertama Project Treble, system baru dalam mekanisme dristribusi Update pada OS Android melalui Internet.\n" +
                    "  - Booting yang sudah sangat cepat\n" +
                    "  - Dukungan lebih banyak variant Emoji baru\n" +
                    "  - Integrasi pertama dan resmi fitur Font Changer\n" +
                    "  - Adaptive themes (Dark / Light)\n" +
                    "  - Peningkatan besar dari sisi System yang kini lebih efektif dan responsif\n" +
                    "  - Peningkatan pada Layout Statusbar dan Notifikasi\n" +
                    "\n" +
                    "Pada OS Android 8.0 ini, pihak Google juga diketahui hanya memberikan 1 kali update pada Sub Versi, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Android 8.0.1 (API Lebel 27)\n" +
                    "Dari OS Android 8.0 ini sebenarnya di mulai era penggunaan Display terbaru dari Smartphone Android, karena biasanya menggunakan Ratio 16:9, maka pada era ini sudah terjadi pergeseran, karena secara Massive para Vendor Smartphone Android menjual dan membuat Smartphone dengan Ratio layar 18:9.\n" +
                    "Jika kita artikan layar Smartphone Android lebih panjang dengan resolusi bari yaitu FullHD+ yang memiliki konsep utama yaitu Full Display dengan hanya sedikit menyisakan Border.",



            "Android 9.0 atau lebih di kenal dengan Codename Pie (API Level 28) yang di rilis pada tahun 2018 menjawab hal tersebut dengan merilis beragan fungsi dan fitur terkait penggunaan Trend Display baru tersebut." +
                    "\n" +
                    "Android Pie ini juga membawa sejumlah perubahan besar pada paket Updatenya, yaitu adalah sebagai berikut :\n" +
                    "\n" +
                    "  - Dukungan penuh terhadap Display Layar 18:9\n" +
                    "  - OS Android pertama yang menggunakan Round Corner (Sudut cekung)\n" +
                    "  - Navigation Bar baru yang Support Gesture untuk memaksimalkan fungsi pada Smartphone Android dengan konsel Full View Display\n" +
                    "  - Update Vulkan API 1.1 yang makin sangar dalam merender Animasi 3D\n" +
                    "  - NFC bisa di gunakan untuk membuka kunci Smartphone\n" +
                    "  - Redesign beberapa Layout Funsionalitas\n" +
                    "  - Animasi Transisi baru\n" +
                    "  - Dukungan peningkatan Security Biometric yang penggunaannya sudah di perluas\n" +
                    "\n" +
                    "Fakta menarik dari Android 9.0 Pie adalah karena Google tidak memberikan Update lagi setelahnya, dalam artian tidak ada Sub Versi pada OS Android 9.0 tersebut, sehingga OS Android 9.0 menjadi OS Android Modern pertama yang tidak memiliki Sub Versi",



            "Rilis pada tahun 2019, membuat OS Android inilah yang menjadi OS Android paling terbaru dan paling canggih yang ada sekarang ini, OS Android 10 ini membawa beberapa Update sebagai berikut :\n" +
                    "\n" +
                    "  - Management App Background yang lebih baik\n" +
                    "  - Penambahan Permission baru dalam penggunaan Aplikasi Android yang membutuhkan Resource\n" +
                    "  - Peningkatan disektor manipulasi Gambar / Foto\n" +
                    "  - Dukungan Format AVI-1 dan HDR+\n" +
                    "  - Peningkatan sektor keamanan Biometric\n" +
                    "  - Dukungan pertama untuk Smartphone berjenis layar lipat (Foldable)\n" +
                    "  - Dukungan Security Protocol WPA3 pada Wi-Fi\n" +
                    "  - Jangkauan Themes Dark Mode yang lebih menyeluruh dari Dark Mode yang ada pada versi sebelumnya.\n" +
                    "  - Penggunaan Project Mainline, yang memungkinkan untuk melakukan Update Core Android OS dengan kemampuan Google Play Store, untuk efesiensi waktu keseluruhan dalam tahap Updating, sehingga bisa menjadi lebih singkat\n" +
                    "\n" +
                    "Sejauh ini, tidak ada Sub Versi dari Android 10 tersebut, karena memang baru saja di rilis ke Publik.",
    };



    private static int[] androidImages = {
            R.drawable.android01,
            R.drawable.android02,
            R.drawable.android03,
            R.drawable.android04,
            R.drawable.android05,
            R.drawable.android06,
            R.drawable.android07,
            R.drawable.android08,
            R.drawable.android09,
            R.drawable.android10,
            R.drawable.android11,
            R.drawable.android12,
            R.drawable.android13,
            R.drawable.android14,
            R.drawable.android15,
            R.drawable.android16
    };

    public static ArrayList<Andro> getListData() {
        ArrayList<Andro> list = new ArrayList<>();
        for (int position = 0; position < androidNames.length; position++) {
            Andro hero = new Andro();
            hero.setName(androidNames[position]);
            hero.setDetail(androidDetails[position]);
            hero.setPhoto(androidImages[position]);
            list.add(hero);
        }
        return list;
    }
}
